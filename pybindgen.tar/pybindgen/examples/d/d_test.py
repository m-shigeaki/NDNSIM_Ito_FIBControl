import sys
sys.path.insert(0, "../../build/examples/d")
from d import *


d = D ()
print d.d
DDoA (d)
DDoB (d)
DDoC (d)

