
==========================================================
gccxmlparser: scan header files to extract API definitions
==========================================================


.. automodule:: pybindgen.gccxmlparser
    :members:
    :undoc-members:
    :show-inheritance:
