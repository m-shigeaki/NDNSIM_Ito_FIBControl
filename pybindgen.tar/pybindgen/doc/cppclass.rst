
==========================================
cppclass: wrap C++ classes or C structures
==========================================


.. automodule:: pybindgen.cppclass
    :members:
    :undoc-members:
    :show-inheritance:
