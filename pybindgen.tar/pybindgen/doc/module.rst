
==============================================================
module: generate Python modules and submodules
==============================================================


.. automodule:: pybindgen.module
    :members:
    :undoc-members:
    :show-inheritance:
