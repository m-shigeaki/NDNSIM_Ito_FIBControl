
=================================================================
typehandlers.codesink: classes that receive generated source code
=================================================================


.. automodule:: pybindgen.typehandlers.codesink
    :members:
    :undoc-members:
    :show-inheritance:
