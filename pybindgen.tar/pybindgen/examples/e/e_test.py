import sys
sys.path.insert(0, "../../build/examples/e")
from e import *

e = E ()
e.Do ()

